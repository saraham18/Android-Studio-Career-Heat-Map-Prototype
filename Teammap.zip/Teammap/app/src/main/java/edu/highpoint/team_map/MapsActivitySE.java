package edu.highpoint.team_map;

import androidx.fragment.app.FragmentActivity;
import androidx.appcompat.widget.SearchView;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.location.Address;
import android.location.Geocoder;
import android.view.View;
import android.widget.CheckBox;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.UiSettings;

import java.io.IOException;
import java.util.List;

import edu.highpoint.team_map.databinding.ActivityMapsSeBinding;

public class MapsActivitySE extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsSeBinding binding;
    SearchView searchView;

    private Marker dallasTX;
    private Marker atlantaGA;
    private Marker coloradoSpringsCO;
    private Marker austinTX;
    private Marker denverCO;

    private Bitmap b;
    private BitmapDescriptor smallMarkerIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps_se);

        // initializing our search view.
        searchView = findViewById(R.id.idSearchView);

        // Obtain the SupportMapFragment and get notified
        // when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        // adding on query listener for our search view.
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // on below line we are getting the
                // location name from search view.
                String location = searchView.getQuery().toString();

                // below line is to create a list of address
                // where we will store the list of all address.
                List<Address> addressList = null;

                // checking if the entered location is null or not.
                if (location != null || location.equals("")) {
                    // on below line we are creating and initializing a geo coder.
                    Geocoder geocoder = new Geocoder(MapsActivitySE.this);
                    try {
                        // on below line we are getting location from the
                        // location name and adding that location to address list.
                        addressList = geocoder.getFromLocationName(location, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // on below line we are getting the location
                    // from our list a first position.
                    Address address = addressList.get(0);

                    // on below line we are creating a variable for our location
                    // where we will add our locations latitude and longitude.
                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());

                    // on below line we are adding marker to that position.
                    mMap.addMarker(new MarkerOptions().position(latLng).title(location));

                    // below line is to animate camera to that position.
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        // at last we calling our map fragment to update.
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng colorado = new LatLng(39.191097, -106.817535);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(colorado));

        // scales the icon on the google map
        int height = 100;
        int width = 100;
        Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.se);
        Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);
        BitmapDescriptor smallMarkerIcon = BitmapDescriptorFactory.fromBitmap(smallMarker);

        final LatLng dallasLocation = new LatLng(32.779167, -96.808891);
        Marker dallasTX = mMap.addMarker(
                new MarkerOptions()
                        .position(dallasLocation)
                        .title("1. Dallas, TX")
                        .snippet("Top Companies: Goldman Sachs, BayInfoTech, Southwest Airlines")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f, 0.5f));

        final LatLng atlantaLocation = new LatLng(33.753746, -84.386330);
        Marker atlantaGA = mMap.addMarker(
                new MarkerOptions()
                        .position(atlantaLocation)
                        .title("2. Atlanta, GA")
                        .snippet("Top Companies: VMware, Turner, Accenture")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f, 0.5f));

        final LatLng coloradoSpringsLocation = new LatLng(38.8339, -104.8214);
        Marker coloradoSpringsCO = mMap.addMarker(
                new MarkerOptions()
                        .position(coloradoSpringsLocation)
                        .title("3. Colorado Springs, CO")
                        .snippet("Top Companies: Boecore, Lockhead Martin, Boeing")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f, 0.5f));

        final LatLng austinLocation = new LatLng(30.2672, -97.7431);
        Marker austinTX = mMap.addMarker(
                new MarkerOptions()
                        .position(austinLocation)
                        .title("4. Austin, TX")
                        .snippet("Top Companies: General Motors, Charles Schwab, Apple")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f, 0.5f));

        final LatLng denverLocation = new LatLng(39.7392, -104.9903);
        Marker denverCO = mMap.addMarker(
                new MarkerOptions()
                        .position(denverLocation)
                        .title("5. Denver, CO")
                        .snippet("Top Companies: FluentStream, Lockhead Martin, Amazon")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f, 0.5f));
    }
}

