package edu.highpoint.team_map;

import androidx.fragment.app.FragmentActivity;
import androidx.appcompat.widget.SearchView;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.location.Address;
import android.location.Geocoder;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

import edu.highpoint.team_map.databinding.ActivityMapsSeBinding;

public class MapsActivityUX extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsSeBinding binding;
    SearchView searchView;

    private Marker sanFranciscoCA;
    private Marker sanDiegoCA;
    private Marker seattleWA;
    private Marker redmondWA;
    private Marker bostonMA;

    private Bitmap b;
    private BitmapDescriptor smallMarkerIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps_ux);

        // initializing our search view.
        searchView = findViewById(R.id.idSearchView);

        // Obtain the SupportMapFragment and get notified
        // when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        // adding on query listener for our search view.
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // on below line we are getting the
                // location name from search view.
                String location = searchView.getQuery().toString();

                // below line is to create a list of address
                // where we will store the list of all address.
                List<Address> addressList = null;

                // checking if the entered location is null or not.
                if (location != null || location.equals("")) {
                    // on below line we are creating and initializing a geo coder.
                    Geocoder geocoder = new Geocoder(MapsActivityUX.this);
                    try {
                        // on below line we are getting location from the
                        // location name and adding that location to address list.
                        addressList = geocoder.getFromLocationName(location, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // on below line we are getting the location
                    // from our list a first position.
                    Address address = addressList.get(0);

                    // on below line we are creating a variable for our location
                    // where we will add our locations latitude and longitude.
                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());

                    // on below line we are adding marker to that position.
                    mMap.addMarker(new MarkerOptions().position(latLng).title(location));

                    // below line is to animate camera to that position.
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        // at last we calling our map fragment to update.
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng colorado = new LatLng(39.191097, -106.817535);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(colorado));

        // scales the icon on the google map
        int height = 100;
        int width = 100;
        Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.ux);
        Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);
        BitmapDescriptor smallMarkerIcon = BitmapDescriptorFactory.fromBitmap(smallMarker);

        final LatLng sanFranciscoLocation = new LatLng(37.7749, -122.4194);
        Marker sanFranciscoCA = mMap.addMarker(
                new MarkerOptions()
                        .position(sanFranciscoLocation)
                        .title("1. San Francisco, CA")
                        .snippet("Top Companies: Google, Twitter, Tesla")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f,0.5f));

        final LatLng sanDiegoLocation = new LatLng(32.7157, -117.1611);
        Marker sanDiegoCA = mMap.addMarker(
                new MarkerOptions()
                        .position(sanDiegoLocation)
                        .title("2. San Diego, CA")
                        .snippet("Top Companies: Garofalo, Blink, 3Q Digital")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f,0.5f));

        final LatLng seattleLocation = new LatLng(47.6062, -122.3321);
        Marker seattleWA = mMap.addMarker(
                new MarkerOptions()
                        .position(seattleLocation)
                        .title("3. Seattle, WA")
                        .snippet("Top Companies: Microsoft, Amazon")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f,0.5f));

        final LatLng redmondLocation = new LatLng(47.673988, -122.121513);
        Marker redmondWA = mMap.addMarker(
                new MarkerOptions()
                        .position(redmondLocation)
                        .title("4. Redmond, WA")
                        .snippet("Top Companies: Microsoft, Nintendo")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f,0.5f));

        final LatLng bostonLocation = new LatLng(42.361145, -71.057083);
        Marker bostonMA = mMap.addMarker(
                new MarkerOptions()
                        .position(bostonLocation)
                        .title("5. Boston, MA")
                        .snippet("Top Companies: Boston Dynamics, Hewlett-Packard, Cisco")
                        .icon(smallMarkerIcon)
                        .anchor(0.5f,0.5f));
    }

}