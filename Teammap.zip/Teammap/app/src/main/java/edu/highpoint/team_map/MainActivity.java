package edu.highpoint.team_map;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    Button fButton;
    Button sButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button fButton = findViewById(R.id.button2);
        fButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                System.out.println("Button Clicked");

                Intent fIntent = new Intent(MainActivity.this, MapsActivitySE.class);
                startActivity(fIntent);
            }
        });

        Button sButton = findViewById(R.id.button3);
        sButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                System.out.println("Button Clicked");

                Intent sIntent = new Intent(MainActivity.this, MapsActivityUX.class);
                startActivity(sIntent);
            }
        });
    }
}